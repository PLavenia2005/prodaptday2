import unittest
from services.registration_service import RegistrationService

class TestRegistration(unittest.TestCase):

    def test_service_creation(self):
        service = RegistrationService()
        self.assertIsNotNone(service)

if __name__ == "__main__":
    unittest.main()