import csv
import os


def read_csv(filename):

    if not os.path.exists(filename):
        raise FileNotFoundError

    with open(filename, "r", newline="") as file:
        return list(csv.DictReader(file))


def write_csv(filename, fieldnames, rows):

    with open(filename, "w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)

        writer.writeheader()

        writer.writerows(rows)

        