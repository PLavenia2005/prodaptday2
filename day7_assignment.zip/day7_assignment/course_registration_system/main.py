from services.registration_service import RegistrationService
from exceptions.custom_exceptions import *

service = RegistrationService()

while True:

    print("\n===== Student Course Registration System =====")
    print("1. View Courses")
    print("2. Add Course")
    print("3. Register Student")
    print("4. Enroll Course")
    print("5. Drop Course")
    print("6. Exit")

    choice = input("Enter choice : ")

    try:

        if choice == "1":
            service.view_courses()

        elif choice == "2":
            service.add_course()

        elif choice == "3":
            service.register_student()

        elif choice == "4":
            service.enroll_course()

        elif choice == "5":
            service.drop_course()

        elif choice == "6":
            print("Thank you")
            break

        else:
            print("Invalid choice")

    except FileNotFoundError:
        print("Error: Course data file not found")

    except CourseNotFound as e:
        print("Error:", e)

    except StudentNotFound as e:
        print("Error:", e)

    except CourseFull as e:
        print("Error:", e)