import time
#add= lambda x,y:x+y
#print(add(5,3))

start_time= time.perf_counter()

find_largest_word = lambda sentence: max(sentence.split(),key=len)
sentence = input("enter a sentence: ")
largest_word = find_largest_word(sentence)
print("largest word:",largest_word)

end_time=time.perf_counter()
execution_time=end_time-start_time
print(f"execution time: {execution_time:.6f} seconds")
