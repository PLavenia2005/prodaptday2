
def find_longest_word(text):
    words = text.split()
    longest_word=""

    for word in words:
        if len(word)>len(longest_word):
            longest_word=word

    return longest_word

sentence = "welcome to python programming language"
print("the longest word is:", find_longest_word(sentence))
    
    
