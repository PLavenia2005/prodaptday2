
from functools import reduce
numbers=[1,2,3,4,5]

product_of_numbers=reduce(lambda x,y:x*y,numbers)
print("Product of numbers:", product_of_numbers)