Linux mission impossible
