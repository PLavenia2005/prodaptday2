datastore = {
    "members": {},
    "books": {},
    "borrows": {}
}