from data.datastore import datastore

class MemberService:

    def add_member(self, member):
        datastore["members"][member.person_id] = member

    def get_member(self, member_id):
        return datastore["members"].get(member_id)

    def update_membership(self, member_id, membership):

        if member_id in datastore["members"]:
            datastore["members"][member_id].membership_type = membership

    def delete_member(self, member_id):

        datastore["members"].pop(member_id, None)

    def display_members(self):

        for member in datastore["members"].values():
            print(member)