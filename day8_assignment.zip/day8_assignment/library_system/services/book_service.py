from data.datastore import datastore

class BookService:

    def add_book(self, book):
        datastore["books"][book.book_id] = book

    def get_book(self, book_id):
        return datastore["books"].get(book_id)

    def update_availability(self, book_id, status):

        if book_id in datastore["books"]:
            datastore["books"][book_id].is_available = status

    def delete_book(self, book_id):
        datastore["books"].pop(book_id, None)

    def display_books(self):

        for book in datastore["books"].values():
            print(book)