class Person:
    def __init__(self, person_id, name, age):
        self.person_id = person_id
        self.name = name
        self.age = age

    def __str__(self):
        return f"ID:{self.person_id}, Name:{self.name}, Age:{self.age}"