from services.member_service import MemberService
from models.member import Member

service = MemberService()

member = Member(1, "Pujitha", 22, "Premium")

service.add_member(member)

assert service.get_member(1).name == "Pujitha"

print("Member Test Passed")