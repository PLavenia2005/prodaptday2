from data.datastore import datastore

class CustomerService:

    def add_customer(self, customer):
        datastore["customers"][customer.person_id] = customer

    def get_customer(self, customer_id):
        return datastore["customers"].get(customer_id)

    def update_prescription(self, customer_id, prescription):

        if customer_id in datastore["customers"]:
            datastore["customers"][customer_id].prescription = prescription

    def delete_customer(self, customer_id):
        datastore["customers"].pop(customer_id, None)

    def display_customers():

        for customer in datastore["customers"].values():
            print(customer)