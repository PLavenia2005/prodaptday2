from data.datastore import datastore

class MedicineService:

    def add_medicine(self, medicine):
        datastore["medicines"][medicine.medicine_id] = medicine

    def get_medicine(self, medicine_id):
        return datastore["medicines"].get(medicine_id)

    def update_stock(self, medicine_id, quantity):

        if medicine_id in datastore["medicines"]:
            datastore["medicines"][medicine_id].quantity = quantity

    def update_price(self, medicine_id, price):

        if medicine_id in datastore["medicines"]:
            datastore["medicines"][medicine_id].price = price

    def delete_medicine(self, medicine_id):
        datastore["medicines"].pop(medicine_id, None)

    def display_medicines(self):

        for medicine in datastore["medicines"].values():
            print(medicine)