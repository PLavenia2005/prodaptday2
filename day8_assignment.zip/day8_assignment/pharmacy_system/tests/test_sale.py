from services.sale_service import SaleService
from models.customer import Customer
from models.medicine import Medicine
from models.sale import Sale

customer = Customer(1, "Pujitha", 22, "Paracetamol")

medicine = Medicine(101, "Paracetamol", "Tablet", 20, 100)

sale = Sale(1001, customer, medicine, 5, "17-07-2026")

service = SaleService()

service.create_sale(sale)

assert medicine.quantity == 95

print("Sale Test Passed")